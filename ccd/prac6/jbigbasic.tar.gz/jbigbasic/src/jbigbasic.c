#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "jbig.h"

#define DEBUG

#define PROGNAME "jbigbasic"

enum ACCION
{
	CODIFICAR,
	PCODIFICAR,
	DECODIFICAR,
	PDECODIFICAR,
};

enum FORMATO
{
	PGM,
	PBM
};

void uso();
unsigned char *LeerImagen(const char *nombre, int *anch, int *alt, enum FORMATO *fmt, int *planos);
unsigned char *calcularDiferencias(const unsigned char *bitmap, const int tam);
unsigned char *decalcularDiferencias(struct jbg_dec_state *s);
void escribir(unsigned char *start, size_t len, void *file);
void codificar(const char *fin, const char *fout, enum ACCION acc);
void decodificar(const char *fin, const char *fout, enum ACCION acc);

int main(int argc, char **argv)
{

	if (argc<4 || argc>5)
	{
		uso();
		exit(EXIT_FAILURE);
	}

	enum ACCION acc;
	int i;

	if (!strcmp(argv[1],"-c"))
		acc = CODIFICAR;
	else if (!strcmp(argv[1],"-d"))
		acc = DECODIFICAR;
	else
	{
		printf("No se ha especificado una accion\n");
		uso();
		exit(EXIT_FAILURE);
	}

	i=2;
	if (!strcmp(argv[2],"-p"))
	{
		i++;
		if (acc == CODIFICAR)
			acc = PCODIFICAR;
		else
			acc = PDECODIFICAR;
	}

	// A trabajar
	if (acc == CODIFICAR || acc == PCODIFICAR)
	{
		codificar(argv[i], argv[i+1], acc);
	}
	else
	{
		decodificar(argv[i], argv[i+1], acc);
	}

	return EXIT_SUCCESS;
}

void uso()
{
	printf("Codificador/decodificar basico PGM/PBM a JBG.\n"
		"Realizado por Ruben Dugo para la asignatura CCD.\n\n"
		"Uso: %s <accion> [opciones] <fichero entrada> <fichero salida>\n\n"
		"El campo accion debe ser uno de los siguientes:\n"
		"  -c\tcodificar\n"
		"  -d\tdecodificar\n\n"
		"Y las opciones:\n"
		"  -p\tpreprocesar/postprocesar la imagen calculando la diferencia de un pixel con el anterior (solo para PGM)\n\n"

		,PROGNAME);
}

unsigned char *LeerImagen(const char *nombre, int *anch, int *alt, enum FORMATO *fmt, int *planos)
{

	char buf[3], aux;
	int ancho, alto, tam, maxval;
	enum FORMATO fmto;
	unsigned char *datos;
	FILE *f;

	if (!(f=fopen(nombre,"r")))
	{
		fprintf(stderr, "Error abriendo fichero de entrada");
		exit(EXIT_FAILURE);
	}

	// Leemos el formato y lo comprobamos.
	fgets(buf, 3, f);

	if (!strcmp(buf,"P5"))
	{
		fmto = PGM;
	}
	else if (!strcmp(buf,"P4"))
	{
		fmto = PBM;
		*planos = 1;
	}
	else
	{
		fprintf(stderr, "Error: Fichero de entrada corrupto o formato no soportado\n");
		exit(EXIT_FAILURE);
	}

	// Posicion lectura +1
	fseek(f, 1, SEEK_CUR);

	// Ignoramos los comentarios
	aux = fgetc(f);
 	while (aux=='#')
	{
		while (aux!='\n')
		{
		  aux = fgetc(f);
		}
	}

	if (aux!='\n') ungetc(aux, f);


	fscanf(f, "%d", &ancho);
	fscanf(f, "%d", &alto);
	if (fmto==PGM)
	{
		fscanf(f, "%d", &maxval);
		int i=1;
		*planos = 0;
		while(i<maxval)
		{
			i=i<<1;
			(*planos)++;
		}
	}

	tam = (fmto==PBM) ? (ancho*alto)/8 + 1 : (ancho*alto);

	#ifdef DEBUG
	printf("maxval: %d\n",maxval);
	printf("ancho: %d \t alto: %d\n",ancho,alto);
	printf("tam: %d\n",tam);
	printf("planos: %d\n",*planos);
	#endif

	datos = (unsigned char *) malloc(tam);

	do
	{
		aux = fgetc(f);
	}
	while(aux != '\n');


	if (fread(datos, 1, tam, f)<(tam-1))
	{
		fprintf(stderr, "Error: El tamaño del fichero de entrada no coincide con sus dimensiones\n");
		fclose(f);
		exit(EXIT_FAILURE);
	}

	fclose(f);

	*anch = ancho;
	*alt = alto;
	*fmt = fmto;

	return datos;
}

unsigned char *calcularDiferencias(const unsigned char *bitmap, const int tam)
{
	unsigned char *aux, *aux2;
	int diferencia,i,j,tam2;

	aux = (unsigned char*)malloc(tam*2);

	// En primer lugar calculamos las diferencias y las almacenamos en un vector
	aux[0] = 1;
	aux[1] = bitmap[0];

	j=2;
	for (i=1;i<tam;i++,j+=2)
	{
		diferencia=((int)bitmap[i]-(int)bitmap[i-1])+256;
		aux[j] = (unsigned char)(diferencia/256);
		aux[j+1] = (unsigned char)(diferencia%256);
	}

	tam2 = (tam*9/8) + 1;

	aux2 = (unsigned char*)malloc(tam2);
	for (i=0;i<tam2;i++) aux2[i] = 0;

	j=0;
	for (i=0;i<tam2;i++)
	{
		if (aux[i]) aux2[i] |= 1<<(7-(j%8));
		j++;
		aux2[i] |= (unsigned char)(((int)aux[i+1])>>(j%8));
		aux2[i+1] |= (unsigned char)(((int)aux[i+1])<<(7-(j%8)));
		j+=8;
	}

	free(aux);
	return aux2;
}

unsigned char *decalcularDiferencias(struct jbg_dec_state *s)
{

	unsigned char *datos,*signo, **capas;
	const int planos = jbg_dec_getplanes(s)-1;
	const long tam = jbg_dec_getwidth(s)*jbg_dec_getheight(s);
	int i,j, bpp, mask;

	// Reservo memoria para cada uno de los planos
	capas = (unsigned char**)malloc(sizeof(unsigned char**)*planos);

	for (i=0;i<planos;i++)
		capas[i] = jbg_dec_getimage(s, i+1);

	// Si tengo mas de 9 planos (uno para el signo) entonces la imagen tenga 2 bytes por pixel
	if (planos>9)
		bpp = 2;
	else
		bpp=1;

	datos = (unsigned char*)malloc(sizeof(unsigned char)*tam*bpp);

	// De esta forma combino los planos
	mask=1<<7;
	for (i=0;i<tam;i+=bpp)
	{
		datos[i] = 0;
		for (j=0;j<planos;j++)
		{
			if (((int)capas[j][(i/8)])&mask)
			{
				datos[i] |= 1<<(7-j);
			}
		}

		mask = (mask>>1) ? mask>>1 : 1<<7;
	}

	// Plano signo de la diferencia
	signo = jbg_dec_getimage(s, 0);

	mask = 1<<7;
	for (i=1;i<tam;i+=bpp)
	{
		datos[i] = (((int)signo[(i/8)])&mask) ? datos[i-1]+datos[i] : datos[i-1]-datos[i];
		mask = (mask>>1) ? mask>>1 : 1<<7;
	}

	return datos;
}

void codificar(const char *fin, const char *fout, enum ACCION acc)
{
	enum FORMATO fmt;
	FILE *fs;
	unsigned char **bitmaps, *imagen;
	int i,ancho,alto,planos;
	struct jbg_enc_state se;

	imagen = LeerImagen(fin, &ancho, &alto, &fmt, &planos);

	// Abrimos el fichero de salida
	if (!(fs=fopen(fout,"w")))
	{
		fprintf(stderr, "Error abriendo fichero de salida\n");
		exit(EXIT_FAILURE);
	}

	if (acc == PCODIFICAR)
	{
		if (fmt == PGM)
		{
			imagen = calcularDiferencias(imagen, ancho*alto);
			planos++;
		}
		else
		{
			printf("Se trata de un fichero PBM, se ignora el parametro -p\n");
		}
	}


	if (fmt==PGM)
	{
		bitmaps = (unsigned char**)malloc(sizeof(unsigned char *) * planos);
		for (i=0;i<planos;i++)
			bitmaps[i] = (unsigned char*)malloc(sizeof(unsigned char) * (ancho*alto)/8 +1);

		jbg_split_planes(ancho, alto, planos, planos, imagen, bitmaps, 1);

		free(imagen);
	}
	else
	{
		bitmaps = (unsigned char**)malloc(sizeof(unsigned char *));
		bitmaps[0] = imagen;
	}

	jbg_enc_init(&se, ancho, alto, planos, bitmaps, escribir, fs);
	jbg_enc_out(&se);
	jbg_enc_free(&se);
}

void decodificar(const char *fin, const char *fout, enum ACCION acc)
{

	FILE *fe,*fs;
	struct jbg_dec_state s;
	long len;
	const int buflen = 20;
	int result, multi=0, max, i;
	unsigned int cnt;
	unsigned char *buf,*p,*imagen;

	jbg_dec_init(&s);

	if (!(fe=fopen(fin,"r")))
	{
		fprintf(stderr, "Error abriendo fichero de entrada");
		exit(EXIT_FAILURE);
	}

	buf = (unsigned char*)malloc(sizeof(char)*buflen);

	if ((len=fread(buf, 1, 20, fe)) < 20)
	{
		fprintf(stderr, "El fichero de entrada debe tener al menos 20 bytes\n");
		fclose(fe);
		exit(EXIT_FAILURE);
	}

	if (buf[19] & JBG_VLENGTH)
	{
		/* VLENGTH = 1 */

		#ifdef DEBUG
		printf("VLENGTH = 1\n");
		#endif

		free(buf);

		// Obtengo la longitud del fichero
		fseek(fe, 0, SEEK_END);
		len = ftell(fe) - 20;
		fseek(fe, 20, SEEK_SET);
		buf = (unsigned char*)malloc(sizeof(char)*len);

		// Lo leo
		fread((void*)buf, sizeof(char), len, fe);

		/* scan for NEWLEN marker segments and update BIE header accordingly */
		result = jbg_newlen(buf, len);
		/* feed data to decoder */
		if (result == JBG_EOK)
		{
		p = buf;
		result = JBG_EAGAIN;
			while (len > 0 && (result == JBG_EAGAIN || (result == JBG_EOK && multi)))
			{
				result = jbg_dec_in(&s, p, len, &cnt);
				p += cnt;
				len -= cnt;
			}
		}
	}
	else
	{
		/* VLENGTH = 0 */

		#ifdef DEBUG
		printf("VLENGTH = 0\n");
		#endif

		result = JBG_EAGAIN;
		do {
			cnt = 0;
			p = buf;
			while (len > 0 && (result == JBG_EAGAIN || (result == JBG_EOK && multi)))
			{
				result = jbg_dec_in(&s, p, len, &cnt);
				p += cnt;
				len -= cnt;
			}
			if (!(result == JBG_EAGAIN || (result == JBG_EOK && multi)))
			break;

			len = fread(buf, 1, buflen, fe);
		}
		while (len > 0);

	}

	if (ferror(fe) || fclose(fe))
	{
		fprintf(stderr, "Se encontro un error leyendo el fichero de entrada");
		exit(EXIT_FAILURE);
	}

	// Abro el fichero de salida
	if (!(fs=fopen(fout,"w")))
	{
		fprintf(stderr, "Error abriendo fichero de salida");
		exit(EXIT_FAILURE);
	}

	#ifdef DEBUG
	printf("Planos obtenidos: %d\n",jbg_dec_getplanes(&s));
	#endif

	if (jbg_dec_getplanes(&s) == 1)
	{
		#ifdef DEBUG
		printf("Fichero PBM (1 plano)\n");
		#endif

		if (acc == PDECODIFICAR) printf("Se trata de un fichero PBM, se ignora el parametro -p\n");

		/* escribe el fichero PBM de salida */
		fprintf(fs, "P4\n%ld %ld\n", jbg_dec_getwidth(&s),jbg_dec_getheight(&s));
		fwrite(jbg_dec_getimage(&s, 0), 1, jbg_dec_getsize(&s), fs);
	}
	else
	{

		#ifdef DEBUG
		printf("Fichero PGM (mas de 1 plano)\n");
		#endif

		/* escribe el fichero PGM de salida */
		if ((int) jbg_dec_getplanes(&s) > sizeof(unsigned long) * 8)
		{
			fprintf(stderr, "La imagen tiene demasiados planos (%d)\n",jbg_dec_getplanes(&s));

			fclose(fs);
			remove(fout);

			exit(EXIT_FAILURE);
		}

		fprintf(fs, "P5\n%ld %ld\n", jbg_dec_getwidth(&s), jbg_dec_getheight(&s));

		if (acc == PDECODIFICAR)
		{
			// Decalculo las diferencias, me sirvo de que la imagen ya esta dividada en planos
			imagen = decalcularDiferencias(&s);
			fprintf(fs, "%d\n", ((jbg_dec_getplanes(&s)>9) ? 512 : 256));
			fwrite((void*)imagen, (jbg_dec_getplanes(&s)>9) ? 2 : 1, jbg_dec_getwidth(&s)*jbg_dec_getheight(&s),fs);
			free(imagen);
		}
		else
		{
			// Con esto se obtiene la profundidad
			max = 0;
			for (i = jbg_dec_getplanes(&s); i > 0; i--)
				max = (max << 1) | 1;

			fprintf(fs, "%d\n", max);


			jbg_dec_merge_planes(&s, 1, escribir, fs);
		}
	}

	// Libera recursos
	jbg_dec_free(&s);
	free(buf);

	if (ferror(fs) || fclose(fs))
	{
		fprintf(stderr, "Error escribiendo en el fichero de salida '%s'", fout);
		perror("'");
		exit(EXIT_FAILURE);
	}
}

void escribir(unsigned char *start, size_t len, void *file)
{
   fwrite(start, 1, len, (FILE *) file);
}

