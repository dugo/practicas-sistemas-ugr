#ifndef __BASELINE_H__
#define __BASELINE_H__

#define BASE_FLOAT_TEST		70.8
#define BASE_INT_TEST		71.0
#define BASE_OUT_TEST		7184.1
#define BASE_IN_TEST		27029.6
#define BASE_MEM_TEST		27391.6

#endif

