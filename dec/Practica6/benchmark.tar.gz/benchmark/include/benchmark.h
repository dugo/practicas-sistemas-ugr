#ifndef __BENCHMARK_H__
#define __BENCHMARK_H__

double float_test(const unsigned int iterations);
double int_test();
double i_test(const unsigned int num_blocks, const unsigned int bl, const char *file);
double o_test(const unsigned int duration, const unsigned int block_size, const char *file);
double mem_test(const unsigned int num, const unsigned int block_size);
void removetmpfile(const char *file);

#endif

