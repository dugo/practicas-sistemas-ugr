#include <stdio.h>
#include <time.h>

// Tamaño por defecto de bloque
#define DEFAULT_BLOCK_SIZE 1024
// Fichero para realizar los tests por defecto
#define DEFAULT_TESTFILE "tmp"

double i_test(const unsigned int duration, const unsigned int block_size, const char *file)
{

	unsigned int n = 0;
	const unsigned int block = (block_size>0)?block_size:DEFAULT_BLOCK_SIZE;
	char buf[block];

	FILE *f = fopen((file)?file:DEFAULT_TESTFILE,"r");

	const unsigned int stoptime = time(NULL) + duration;

	do 
	{
		fread(buf, block, 1, f);
		n++;
	}
	while(stoptime>time(NULL));

	fclose(f);

	return (double)(n*block)/(double)duration;
}

double o_test(const unsigned int duration, const unsigned int block_size, const char *file)
{

	unsigned int n = 0;
	const unsigned int block = (block_size>0)?block_size:DEFAULT_BLOCK_SIZE;
	const char buf[block];

	FILE *f = fopen((file)?file:DEFAULT_TESTFILE,"w");

	const unsigned int stoptime = time(NULL) + duration;

	do
	{
		fwrite(buf, block, 1, f);
		n++;
	}
	while(stoptime>time(NULL));

	fclose(f);

	return (double)(n*block)/(double)duration;
}

void removetmpfile(const char *file)
{
	remove((file)?file:DEFAULT_TESTFILE);
}

