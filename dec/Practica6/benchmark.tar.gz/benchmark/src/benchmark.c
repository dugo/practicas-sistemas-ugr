#include <stdio.h>
#include <stdlib.h>
#include "benchmark.h"
#include "base.h"

void uso()
{
	printf("Error en los parámetros\nUso: benchmark <repeticiones>\n\tA mayor número de repeticiones mayor precisión es los cálculos, mínima 1, recomendadas 3.\n");
}

int main(int argc, char **argv)
{

	if (argc!=2)
	{
		uso();
		exit(-1);
	}

	int rep = atoi(argv[1]);
	if (rep<0)
	{
		uso();
		exit(-1);
	}

	double result[5];
	int i;

	for (i=0;i<5;i++)
		result[i] = 0.0;

	printf("Test de operaciones en coma flotante..."); fflush(stdout);
	for (i=0;i<rep;i++)
	{
		printf("%d...",i+1); fflush(stdout);
		result[0] += float_test(3000000000u);
	}

	printf("OK!\nTest de operaciones con enteros..."); fflush(stdout);
	for (i=0;i<rep;i++)
	{
		printf("%d...",i+1); fflush(stdout);
		result[1] += int_test(4000000000u);
	}

	printf("OK!\nTest de E/S..."); fflush(stdout);
	for (i=0;i<rep;i++)
	{
		printf("%d...",i+1); fflush(stdout);

		// Tamaño de bloque 1024 bytes
		result[2] += o_test(10,1024,NULL);
		result[3] += i_test(10,1024,NULL);
		removetmpfile(NULL);
		// Tamaño de bloque 256 bytes
		result[2] += o_test(10,256,NULL);
		result[3] += i_test(10,256,NULL);
		removetmpfile(NULL);
		// Tamaño de bloque 4096 bytes
		result[2] += o_test(10,4096,NULL);
		result[3] += i_test(10,4096,NULL);
		removetmpfile(NULL);
	}
	// Media aritmética de los 3 tamaños de bloque
	result[2] = result[2] / 3.0;
	result[3] = result[3] / 3.0;

	printf("OK!\nTest de memoria..."); fflush(stdout);
	for (i=0;i<rep;i++)
	{
		printf("%d...",i+1); fflush(stdout);
		// Tamaño de bloque 1024 bytes
		result[4] += mem_test(100000, 1024);
		// Tamaño de bloque 256 bytes
		result[4] += mem_test(100000, 256);
		// Tamaño de bloque 4096 bytes
		result[4] += mem_test(50000, 4096);
	}
	result[4] = result[4]/3.0;

	printf("OK!\n\n");

	for (i=0;i<5;i++)
		result[i] = result[i]/(double)rep;

	// Cada valor a su unidad
	result[0] = result[0]/1000000.0;
	result[1] = result[1]/1000000.0;
	result[2] = result[2]/1024.0;
	result[3] = result[3]/1024.0;
	result[4] = result[4]/1024.0;

	printf("TEST                              RESULTADO             BASE             ÍNDICE\n");
	printf("Operaciones en coma flotante     %10.1f MFlops%10.1f MFlops  %10.1f\n", result[0], BASE_FLOAT_TEST, result[0]/BASE_FLOAT_TEST);
	printf("Operaciones con enteros          %10.1f MOps  %10.1f MOps    %10.1f\n", result[1], BASE_INT_TEST, result[1]/BASE_INT_TEST);
	printf("Escritura en disco               %10.1f KB/s  %10.1f KB/s    %10.1f\n", result[2], BASE_OUT_TEST, result[2]/BASE_OUT_TEST);
	printf("Lectura de disco                 %10.1f KB/s  %10.1f KB/s    %10.1f\n", result[3], BASE_IN_TEST, result[3]/BASE_IN_TEST);
	printf("Memoria                          %10.1f KB/s  %10.1f KB/s    %10.1f\n", result[4], BASE_MEM_TEST, result[4]/BASE_MEM_TEST);
	printf("                                                                        =========\n"); 
	printf("Puntuación                                                             %10.1f\n", 
		result[0]/BASE_FLOAT_TEST+
		result[1]/BASE_INT_TEST+
		result[2]/BASE_OUT_TEST+
		result[3]/BASE_IN_TEST+
		result[4]/BASE_MEM_TEST
	);


	return 0;
}
