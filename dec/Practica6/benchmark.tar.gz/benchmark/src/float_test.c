#include <time.h>

double float_test(const unsigned int iterations)
{
	// Registros, de forma que me afecten lo menos posible las operaciones de E/S a memoria
	register unsigned int n = 0;
	register double val1 = 897987, val2=90871823;
	const clock_t start = clock();
	unsigned int stop;

	for (;n<iterations;n++)
	{
		val1 = val1*val2;
		n++;
	}
	stop = clock();

	return (double)iterations/((stop-start)/((double)CLOCKS_PER_SEC));
}

