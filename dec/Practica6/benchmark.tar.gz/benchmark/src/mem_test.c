#include <stdlib.h>
#include <time.h>

// Tamaño por defecto de bloque
#define DEFAULT_BLOCK_SIZE 1024*2
// Fichero para realizar los tests por defecto
#define DEFAULT_BLOCK_NUM 1024*64

inline void copy(char *dest, const char *orig, const unsigned int n)
{
	register int i = 0;
	for (;i<n;i++)
	{
		dest[i] = orig[i];
	}
}

double mem_test(const unsigned int num, const unsigned int block_size)
{
	const unsigned int n = (num>0)?num:DEFAULT_BLOCK_NUM;
	const unsigned int block = (block_size>0)?block_size:DEFAULT_BLOCK_SIZE;
	clock_t stop, start = clock();
	unsigned int i = 0;

	char *buf1 = (char*)malloc(block*n);
	char *buf2 = (char*)malloc(block);
	char *p = buf1;

	for (;i<n;i++,p+=block)
	{
		copy(buf2, p, block);
	}
	stop = clock();

	free(buf1);
	free(buf2);

	return (double)(block*num)/((stop-start)/((double)CLOCKS_PER_SEC));
}

